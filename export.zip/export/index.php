
<?php

    include 'components/header.php';

    // include 'components/topline.php';
    
    // include 'components/navbar.php';

    // include 'components/breadcrumb.php';

?>
    
    <!-- Контент -->
    <section class="content">
        <div class="container-xl px-3 py-5">

            <h4><a href="index-page.php">Главная страница</a></h4>
            <h4><a href="service-page.php">Услуга</a></h4>
            <h4><a href="doctor-page.php">Врач</a></h4>
        
        </div>
    </section>
    <!-- Контент -->

    <?php

        // include 'components/contactform.php';

        // include 'components/footer.php';

    ?>

    
</body>
</html>