
    <!-- Крошки -->
    <div class="breadcrumb d-flex">
        <a href="" class="link-darkblue opacity-50">Главная</a>
        <span class="px-2 text-style-darkblue">></span>
        <a href="" class="link-darkblue opacity-50">Услуги и цены</a>
        <span class="px-2 text-style-darkblue">></span>
        <div class="text-style-darkblue">Ортопедия и травматология</div>
    </div>
    <!-- / Крошки -->