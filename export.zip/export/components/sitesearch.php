
<!-- Поиск по сайту -->
    <form action="" class="site-search-form">
        <div class="site-search-name">
            <input type="text" name="site-search-name" placeholder="Поиск по сайту" class="text-style-darkblue fs-5">
        </div>
        <button type="submit" name="site-search-submit" class="bg-style-lightblue bg-gradient">
            <img src="./assets/img/icons/search.svg" alt="">
        </button>
    </form>
<!-- / Поиск по сайту -->