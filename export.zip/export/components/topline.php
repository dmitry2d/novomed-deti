
    <!-- Верхняя полоска -->
    <section class="top-line">
        <div class="container-xl px-3 px-3 d-none d-md-block">
            <div class="row py-3">
                <div class="col-9">
                    <span class="align-middle d-none d-lg-inline">
                        г. Новороссийск, ул. Свердлова 36А
                    </span>
                    <a href="tel:+78617799799" class="mx-3 align-middle">+7 (8617) 799-799</a>
                    <span class="align-middle">
                        Ежедневно, с 08:00 до 20:00
                    </span>
                </div>
                <div class="col-3 top-line__links text-end">
                    <a href="" class="fab fa-youtube px-1 text-dark"></a>
                    <a href="" class="fab fa-vk px-1 text-dark"></a>
                    <a href="" class="fa fa-eye px-1 text-dark"></a>
                </div>
            </div>
        </div>
    </section>
    <!-- Верхняя полоска -->